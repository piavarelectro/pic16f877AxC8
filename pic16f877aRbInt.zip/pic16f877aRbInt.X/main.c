/*
 * PIC16F877a Port B Interrupt On Change
 * Example in xc8
 */
#include <xc.h>

// PIC16F877A Configuration Bit Settings
// CONFIG
#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 20e6

void main(void){
    /*Clear IO port*/
    PORTB=0x00;
    /*RB0...1 input*/
    TRISB=0xF0;
    /*Turn on Pull Up Resistor*/
    nRBPU=0;
    /*Turn On External Interrupt*/
    RBIE=1;
    /*Turn On Global Interrupt*/
    GIE=1;
    /*Clear Interrupt Flag*/
    RBIF=0;
    while(1){
        RB0^=1;
        __delay_ms(500);
    }
}

/*Interrupt Service Routine*/
void interrupt portBChange(void){
    /*Check RB Port Change Interrupt Present*/
    if(RBIE&&RBIF){
        if(RB4^1) RB1=1;
        if(RB5^1) RB1=0;
        if(RB6^1) RB2=1;
        if(RB7^1) RB2=0;
        RBIF=0;
    }
}